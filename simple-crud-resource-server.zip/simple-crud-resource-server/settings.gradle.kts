rootProject.name = "simple-crud-resource-server"
