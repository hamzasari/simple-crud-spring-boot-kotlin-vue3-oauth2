package com.hamzasari.simplecrudresourceserver

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SimpleCrudResourceServerApplication

fun main(args: Array<String>) {
	runApplication<SimpleCrudResourceServerApplication>(*args)
}
